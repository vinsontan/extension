import logging
import functools
import time
from concurrent.futures import ThreadPoolExecutor
from typing import List
import collections
import re
import socket

from ruxit.api.base_plugin import RemoteBasePlugin
from generic_os_api import Interface, MPStatResult, ProcStatCpu, ProcStatResult, Process, RemoteHost, OS, STANDARD_LINUX, PROPRIETARY_LINUX, SarDisk

log = logging.getLogger(__name__)

def time_it(log_level=logging.INFO):
    def wrap(f):
        def wrapped_function(*args, **kwargs):
            start = time.time()
            f(*args, **kwargs)
            delta = time.time() - start
            if log_level == logging.INFO:
                log.info(f"Execution of {f.__name__} took {delta:.3f} seconds")
            elif log_level == logging.DEBUG:
                log.debug(f"Execution of {f.__name__} took {delta:.3f} seconds")
        return wrapped_function
    return wrap


def exception_logger(function):
    """
    Annotation used to log method exceptions
    """

    @functools.wraps(function)
    def wrapper(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except Exception as e:
            args[0].logger.exception(f"{args[0].config.get('hostname')} - error executing {function.__name__}: '{e}'")
            raise

    return wrapper

class RemoteAgentExtension(RemoteBasePlugin):
    def initialize(self, **kwargs):
        self.execution_count = 0
        self.had_successfull_run = False # used to decide if a connection error should throw and error on UI or just be reported as an outage
        self.result_store = {}
        self.stored_remote_host = None
        self.previous_pids: dict[Process] = {}
        self.should_use_netstat: bool = False


    @time_it(logging.INFO)
    def query(self, **kwargs):

        log.setLevel(self.config.get("log_level", "INFO"))

        self.clean_up_configs()

        alias = self.config.get("alias") if self.config.get("alias") else self.config.get("hostname")

        group = self.topology_builder.create_group(self.config.get("group"), self.config.get("group"))
        self.device = group.create_device(alias)

        password = self.config.get("password") if self.config.get("password") else None
        key_path = self.config.get("ssh_key_file") if self.config.get("ssh_key_file") else None
        ssh_key_contents = self.config.get("ssh_key_contents") if self.config.get("ssh_key_contents") else None
        passphrase = self.config.get("ssh_key_passphrase") if self.config.get("ssh_key_passphrase") else None

        custom_path = self.config.get("custom_path", "") if self.config.get("custom_path", "") != "" else None

        # Password field doesn't preserve newlines which results in invalid SSH key - this method parses what is available and constructs a valid key
        if ssh_key_contents is not None:
            if "\n" not in ssh_key_contents:
                log.info(f"No newlines detected in key contents, will process it to valid key.")
                ssh_key_contents = create_valid_key_from_text(ssh_key_contents)

        if self.stored_remote_host:
            log.debug(f"Using stored remote host.")
            self.remote_host = self.stored_remote_host
        else:
            log.info(f"Creating new remote host.")
            self.remote_host = RemoteHost(
                OS(self.config.get("os", None)),
                self.config.get("hostname"),
                self.config.get("username"),
                self.config.get("port", 22),
                password=password,
                private_key_path=key_path,
                private_key_contents=ssh_key_contents,
                private_key_password=passphrase,
                disable_rsa2=self.config.get("disable_rsa2", False),
                log=log,
                custom_path=custom_path
            )
            self.stored_remote_host = self.remote_host

        self.should_report_properties = True if ((self.execution_count % 30 == 0) or self.execution_count == 0) else False

        if self.should_report_properties:
            self.report_additional_props()

        try:
            host_is_available = True
            if self.config.get("persist_ssh_connection", True):
                if self.execution_count == 0:
                    log.info(f"Creating inital connection.")
                    self.remote_host.connect_for_persisted_connection()
                try:
                    log.debug("Testing connection.")
                    lines = self.remote_host.run_command("echo 1")
                    if lines[0] != "1":
                        log.warning("Test command output not expected value.")
                        raise Exception("Test command output not expected value.")
                    log.debug("Connection test successful.")
                except Exception as e:
                    log.warning(f"Connection test failed. Attempting to repoen.")
                    self.remote_host.connect_for_persisted_connection()
                self.collect_data(persist_connection=True)

            else:
                self.collect_data(persist_connection=False)

            self.had_successfull_run = True

        except Exception as e:
            host_is_available = False
            if self.had_successfull_run or not self.config.get("fail_on_initial_error", False):
                self.device.report_custom_info_event(f"{e}", "Error connecting to host." )
                log.warning(f"Error connecting to {self.config.get('hostname')}: {e}")
            else:
                raise ConnectionError(f"Initial error on connection to {self.config.get('hostname')}: {e}")

        self.device.absolute("availability", 1 if host_is_available else 0)    

        self.execution_count += 1

    def close(self, **kwargs):
        if self.remote_host:
            self.remote_host.disconnect()

    def collect_data(self, persist_connection: bool = True):
        if persist_connection:
            with self.remote_host.reuse_connection():
                self.execute_commands_for_data()
        else:
            with self.remote_host.connect():
                self.execute_commands_for_data()

    def execute_commands_for_data(self):
        with ThreadPoolExecutor(max_workers=5) as e:
            if self.remote_host.os in STANDARD_LINUX:
                e.submit(self.run_and_send_vmstat)
                e.submit(self.run_and_send_w)
                e.submit(self.run_and_send_df)
                e.submit(self.run_and_send_cat_proc_meminfo)
                e.submit(self.get_top_procs_via_top)
                e.submit(self.run_and_send_cat_proc_stat)
                e.submit(self.get_filtered_procs_via_pgrep_and_top)
                e.submit(self.run_and_send_iostat)
                if self.should_use_netstat:
                    e.submit(self.run_and_send_netstat)
                else:
                    e.submit(self.run_and_send_ip)
            if self.remote_host.os == OS.MAC_OS:
                e.submit(self.run_and_send_df)
                e.submit(self.run_and_send_w)
                e.submit(self.run_and_send_netstat)
                e.submit(self.get_uptime_via_ps)
                e.submit(self.get_filtered_procs_via_ps_and_grep)
                e.submit(self.get_top_procs_via_top)
                e.submit(self.run_and_send_iostat)
                e.submit(self.run_and_send_vm_stat)
            if self.remote_host.os in PROPRIETARY_LINUX:
                if self.remote_host.os == OS.SOLARIS:
                    e.submit(self.get_filtered_procs_via_ps_and_grep)
                    e.submit(self.get_procs_via_prstat)
                    e.submit(self.run_and_send_kstat_for_uptime)
                    e.submit(self.run_and_send_mpstat)
                    e.submit(self.run_and_send_iostat)
                    e.submit(self.run_and_send_swap)
                elif self.remote_host.os == OS.AIX:
                    e.submit(self.get_top_procs_via_ps)
                    e.submit(self.get_filtered_procs_via_ps_and_grep)
                    e.submit(self.get_uptime_via_ps)
                    e.submit(self.get_memory_via_svmon)
                    e.submit(self.run_and_send_mpstat)
                    e.submit(self.run_and_send_iostat)
                elif self.remote_host.os == OS.FREE_BSD:
                    e.submit(self.get_uptime_via_ps)
                    e.submit(self.get_top_procs_via_top)
                    e.submit(self.get_filtered_procs_via_ps_and_grep)
                    e.submit(self.run_and_send_iostat)
                elif self.remote_host.os == OS.HP_UX:
                    e.submit(self.get_uptime_via_ps)
                    e.submit(self.get_filtered_procs_via_ps_and_grep)
                    e.submit(self.run_and_send_swapinfo_for_mem)
                    e.submit(self.get_top_procs_via_top)
                    e.submit(self.get_top_procs_via_ps)
                    e.submit(self.run_and_send_sar_disks)
                e.submit(self.run_and_send_vmstat)
                e.submit(self.run_and_send_w)
                e.submit(self.run_and_send_df)
                e.submit(self.run_and_send_netstat)
            if self.should_report_properties:
                e.submit(self.run_and_report_uname)
                e.submit(self.run_and_report_release)
                self.device.report_property("Extension OS", self.remote_host.os.value)
                try:
                    self.device.add_endpoint(socket.gethostbyname(self.remote_host.hostname))
                except Exception as e:
                    log.warn(f"Can't determine IP address from hostname: {self.remote_host.hostname}")

    def report_additional_props(self):
        properties = self.config.get("additional_props", "").split("\n") if self.config.get ("additional_props") else []
        for property in properties:
            try:
                property = property.strip()
                key, value = property.split("=")
                self.device.report_property(key, value)
            except Exception as e:
                log.warn(f"{self.config.get('hostname')} - Unable to report property {property}: e")

    @time_it(logging.DEBUG)
    @exception_logger
    def run_and_send_vm_stat(self):
        result = self.remote_host.run_vm_stat()
        self.device.relative("paged_in", result.paged_in)
        self.device.relative("paged_out", result.paged_out)

    @time_it(logging.DEBUG)
    @exception_logger
    def run_and_send_vmstat(self):

        result = self.remote_host.run_vmstat()

        log.debug(f"vmstat = {result}")
        self.device.absolute("cpu_user", result.cpu_user)
        self.device.absolute("cpu_system", result.cpu_system)
        self.device.absolute("cpu_idle", result.cpu_idle)
        self.device.absolute("cpu_utilization", result.cpu_utilization)
        self.device.absolute("paged_in", result.paged_in)
        self.device.absolute("paged_out", result.paged_out)

        if result.waiting_processes:
            self.device.absolute("waiting_processes", result.waiting_processes)
        
        if self.remote_host.os in [OS.FREE_BSD, OS.HP_UX, OS.SOLARIS]:
            self.device.absolute("physical_memory_free", result.memory_free)
            self.device.absolute("physical_memory_used_percent", result.memory_used_percent)

    @time_it(logging.DEBUG)
    @exception_logger
    def get_top_procs_via_top(self):
        result = self.remote_host.run_top_for_top_procs(threads_mode=self.config.get("top_threads_mode", False))
        if self.remote_host.os == OS.HP_UX:
            # right now only getting CPU breakdown via this command for HP-UX
            pass
        elif self.remote_host.os == OS.MAC_OS:
            self.device.absolute("cpu_user", result.cpu_user)
            self.device.absolute("cpu_system", result.cpu_sys)
            self.device.absolute("cpu_idle", result.cpu_idle)
            self.device.absolute("cpu_utilization", result.cpu_utilization)
            self.device.absolute("physical_memory_free", result.phys_mem_unused)
            self.device.absolute("physical_memory_used_percent", result.memory_used_percent)
            self.device.absolute("swap_free", result.free_swap)
            self.device.absolute("swap_used_percent", result.swap_utilized)
            self.device.absolute("swap_free_percent", (100 - result.swap_utilized))
        elif self.remote_host.os == OS.FREE_BSD:
            self.device.absolute("swap_free", result.free_swap)
            self.device.absolute("swap_used_percent", result.swap_utilized)
            self.device.absolute("swap_free_percent", (100 - result.swap_utilized))
        elif self.remote_host.os in PROPRIETARY_LINUX:
            self.device.absolute("physical_memory_free", result.phys_mem)
            self.device.absolute("physical_memory_used_percent", result.phys_mem_utilized)
            self.device.absolute("swap_free", result.free_swap)
            self.device.absolute("swap_used_percent", result.swap_utilized)
            self.device.absolute("swap_free_percent", (100 - result.swap_utilized))

        for process in result.processes:
            self.device.absolute("top_process_cpu", process.cpu, {"Process": process.name, "PID": str(process.pid)})
            self.device.absolute("top_process_size", process.res, {"Process": process.name, "PID": str(process.pid)})

        # sometimes use top to get CPU breakdown
        if len(result.cpus) > 0:
            if len(result.cpus) == 1:
                self.device.absolute("cpu_user", result.cpus[0].user_percentage)
                self.device.absolute("cpu_system", result.cpus[0].sys_percentage)
                self.device.absolute("cpu_idle", result.cpus[0].idle_percentage)
                self.device.absolute("cpu_utilization", result.cpus[0].user_percentage + result.cpus[0].sys_percentage)
            else:
                for cpu in result.cpus:
                    self.device.absolute("individual_cpu_time_user", cpu.user_percentage, {"Id": cpu.id})
                    self.device.absolute("individual_cpu_time_system", cpu.sys_percentage, {"Id": cpu.id})
                    self.device.absolute("individual_cpu_time_idle", cpu.idle_percentage, {"Id": cpu.id})

    @time_it(logging.DEBUG)
    @exception_logger
    def get_filtered_procs_via_pgrep_and_top(self):
        patterns: List[str] = self.config.get("process_filter", "").split("\n") if self.config.get("process_filter") else []
        pattern_dict = {}
        for pattern in patterns:
            regex, key = pattern.rsplit(";", 1)
            pattern_dict.update({key.strip(): regex})
        process_map = self.remote_host.get_filtered_procs_via_pgrep_and_top(threads_mode=self.config.get("top_threads_mode", False), patterns=pattern_dict)
        for key in process_map:
            self.device.absolute("filtered_process_match_count", len(process_map[key]), {"Process": key})
            current_pids = []
            for process in process_map[key]:
                current_pids.append(process.pid)
                # self.device.absolute("filtered_process_cpu", process.cpu, {"Process": key, "PID": str(process.pid)})
                self.device.absolute("filtered_process_group_cpu", process.cpu, {"Name": process.name, "Group": key, "PID": str(process.pid)})
                # self.device.absolute("filtered_process_size", process.res, {"Process": key, "PID": str(process.pid)})
                self.device.absolute("filtered_process_group_size", process.res, {"Name": process.name, "Group": key, "PID": str(process.pid)})

            log.debug(f"PID match check for pattern {key}: [current: {current_pids}, previous: {self.previous_pids.get(key, [])}]")
            if self.previous_pids.get(key, False):
                if current_pids != []:
                    pids_match = collections.Counter(current_pids) == collections.Counter(self.previous_pids[key])
                    self.device.absolute("filtered_process_pids_changed", 0 if pids_match else 1, {"Process": key})
                    self.previous_pids.update({key: current_pids})
                else:
                    pass
            elif not self.previous_pids.get(key, False):
                if current_pids != []:
                    self.previous_pids.update({key: current_pids})
                else:
                    pass

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_w(self):
        result = self.remote_host.run_w()
        self.device.absolute("user_count", result.user_count)
        self.device.absolute("load_avg_1_min", result.load_average_1_min)
        self.device.absolute("load_avg_5_min", result.load_average_5_min)
        self.device.absolute("load_avg_15_min", result.load_average_15_min)

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_df(self):
        result = self.remote_host.run_df()
        mount_patterns_to_include = self.config.get("mounts_to_include", ".*").split("\n") if self.config.get("mounts_to_include") else [".*"]
        mounts_patterns_to_exclude = self.config.get("mounts_to_exclude", "").split("\n") if self.config.get("mounts_to_exclude") else []
        for mount in result.mounts:
            should_report = False
            for include_regex in mount_patterns_to_include:
                if re.findall(include_regex, mount.file_system) or re.findall(include_regex, mount.mounted_on):
                    should_report = True
                    for exclude_regex in mounts_patterns_to_exclude:
                        if re.findall(exclude_regex, mount.file_system) or re.findall(exclude_regex, mount.mounted_on):
                            should_report = False
            if should_report:
                log.debug(f"Reporting filesystem: '{mount.file_system}' mounted on: '{mount.mounted_on}'")
                self.device.absolute("mount_capacity", mount.capacity, dimensions={"Mount": mount.mounted_on})
                self.device.absolute("mount_used", mount.used, dimensions={"Mount": mount.mounted_on})
                self.device.absolute("mount_available", mount.available, dimensions={"Mount": mount.mounted_on})
            else:
                log.debug(f"Not reporting filesystem: '{mount.file_system}' mounted on: '{mount.mounted_on}'")

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_cat_proc_meminfo(self):
        result = self.remote_host.run_cat_proc_meminfo()
        self.device.absolute("physical_memory_free", result.memory_available)
        if result.memory_used_percent:
            self.device.absolute("physical_memory_used_percent", result.memory_used_percent)
        self.device.absolute("swap_free", result.swap_free)
        self.device.absolute("swap_total", result.swap_total)
        if result.swap_used_percent is not None:
            self.device.absolute("swap_used_percent", result.swap_used_percent)
            self.device.absolute("swap_free_percent", (100 - result.swap_used_percent))

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_cat_proc_stat(self):
        result = self.remote_host.run_cat_proc_stat()
        self.device.absolute("waiting_processes", result.procs_blocked)
        self.device.absolute("uptime", result.uptime_seconds)

        previous_result: ProcStatResult = self.result_store.get("run_and_send_cat_proc_stat", None) # checking if we have data from the last run
        if previous_result:
            for cpu in result.cpus:
                current_cpu: ProcStatCpu = result.cpus[cpu]
                if current_cpu.id == "OVERALL":
                    continue
                else:
                    old_cpu: ProcStatCpu = previous_result.cpus.get(current_cpu.id)
                    if current_cpu and old_cpu:
                        user_delta = current_cpu.user_time - old_cpu.user_time
                        system_delta = current_cpu.system_time - old_cpu.system_time
                        idle_delta = current_cpu.idle_time - old_cpu.idle_time
                        io_wait_delta = current_cpu.iowait_time - old_cpu.iowait_time
                        total_delta = current_cpu.total_time - old_cpu.total_time

                        self.device.absolute("individual_cpu_time_user", (user_delta / total_delta) * 100, {"Id": current_cpu.id})
                        self.device.absolute("individual_cpu_time_system", (system_delta / total_delta) * 100, {"Id": current_cpu.id})
                        self.device.absolute("individual_cpu_time_idle", (idle_delta / total_delta) * 100, {"Id": current_cpu.id})
                        self.device.absolute("individual_cpu_time_iowait", (io_wait_delta / total_delta) * 100, {"Id": current_cpu.id})
        else:
            log.debug("No previous cpu info, probably first run.")
                
        self.result_store["run_and_send_cat_proc_stat"] = result # storing previous result for next run

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_ip(self):
        result = self.remote_host.run_ip()
        if len(result.interfaces) == 0 and self.remote_host.os in STANDARD_LINUX:
            log.info(f"No interfaces found in ip command output for Debian based host, switching to netstat for future runs.")
            self.run_and_send_netstat()
            self.should_use_netstat = True
        else:
            for interface in result.interfaces:
                if interface.name == "lo":
                    continue # no need to report loopback interface
                if self.should_report_properties:
                    self.device.add_endpoint(interface.ipv4)
                self.device.relative("network_bytes", interface.bytes_received, {"Interface": interface.name, "Direction": "Incoming"})
                self.device.relative("packets", interface.packets_received, {"Interface": interface.name, "Direction": "Incoming"})
                self.device.relative("network_errors", interface.errors_incoming, {"Interface": interface.name, "Direction": "Incoming"})
                self.device.relative("packets_dropped", interface.packets_dropped_incoming, {"Interface": interface.name, "Direction": "Incoming"})

                self.device.relative("network_bytes", interface.bytes_sent, {"Interface": interface.name, "Direction": "Outgoing"})
                self.device.relative("packets", interface.packets_sent, {"Interface": interface.name, "Direction": "Outgoing"})
                self.device.relative("network_errors", interface.errors_outgoing, {"Interface": interface.name, "Direction": "Outgoing"})
                self.device.relative("packets_dropped", interface.packets_dropped_outgoing, {"Interface": interface.name, "Direction": "Outgoing"})

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_report_uname(self):
        result = self.remote_host.run_uname()
        self.device.report_property("Kernel", f"{result.kernel_name} {result.kernel_version}")
        self.device.report_property("Hostname", result.hostname)

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_report_release(self):
        try:
            if self.remote_host.os == OS.AIX:
                version = self.remote_host.get_aix_version()
                self.device.report_property("Release", f"AIX {version}")
            if self.remote_host.os == OS.HP_UX:
                pass
            else:
                result = self.remote_host.get_release_info()
                self.device.report_property("Release", f"{result}")
        except Exception as e:
            log.warning(f"Unable to determine release details from /etc/*-release (or oslevel command for AIX).")

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_iostat(self):
        result = self.remote_host.run_iostat()
        if self.remote_host.os == OS.MAC_OS:
            for disk in result.disks:
                self.device.absolute("bytes_per_transfer", disk.bytes_per_transfer, {"Disk": disk.device})
                self.device.absolute("transfers", disk.transfers_per_second, {"Disk": disk.device})
        else:
            for disk in result.disks:
                self.device.relative("disk_read", disk.bytes_read, {"Disk": disk.device})
                self.device.relative("disk_write", disk.bytes_written, {"Disk": disk.device})

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_kstat_for_uptime(self):
        self.device.absolute("uptime", self.remote_host.run_kstat_for_uptime())

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_mpstat(self):
        result: MPStatResult = self.remote_host.run_mpstat()
        for cpu in result.cpus:
            self.device.absolute("individual_cpu_time_user", cpu.user_percentage, {"Id": cpu.id})
            self.device.absolute("individual_cpu_time_system", cpu.sys_percentage, {"Id": cpu.id})
            self.device.absolute("individual_cpu_time_idle", cpu.idle_percentage, {"Id": cpu.id})

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_netstat(self):
        interfaces: List[Interface] = self.remote_host.run_netstat()
        for interface in interfaces:
            if not interface.network.startswith("link") and not interface.name.startswith("lo"): # no loopback or 'link' interfaces from AIX
                self.device.relative("packets", interface.in_packets, dimensions={"Interface": interface.name, "Direction": "Incoming"})
                self.device.relative("packets", interface.out_packets, dimensions={"Interface": interface.name, "Direction": "Outgoing"})
                self.device.relative("network_errors", interface.in_errors, dimensions={"Interface": interface.name, "Direction": "Outgoing"})
                self.device.relative("network_errors", interface.out_errors, dimensions={"Interface": interface.name, "Direction": "Incoming"})
                if self.should_report_properties:
                    if interface.address != "":
                        self.device.add_endpoint(interface.address)

    @time_it(logging.DEBUG) 
    @exception_logger
    def get_top_procs_via_ps(self):
        processes = self.remote_host.run_ps_for_top_procs()
        count = 0
        for process in processes:
            self.device.absolute("top_process_cpu", process.cpu, {"Process": process.name, "PID": str(process.pid)})
            self.device.absolute("top_process_size", process.size, {"Process": process.name, "PID": str(process.pid)})
            count += 1
            if count >= 10:
                break 

    @time_it(logging.DEBUG) 
    @exception_logger
    def get_filtered_procs_via_ps_and_grep(self):
        patterns: List[str] = self.config.get("process_filter", "").split("\n") if self.config.get("process_filter") else []
        pattern_dict = {}
        for pattern in patterns:
            regex, key = pattern.rsplit(";", 1)
            pattern_dict.update({key.strip(): regex})
        process_map = self.remote_host.run_ps_for_filtered_procs(pattern_dict)
        for key in process_map:
            self.device.absolute("filtered_process_match_count", len(process_map[key]), {"Process": key})
            current_pids = []
            for process in process_map[key]:
                current_pids.append(process.pid)
                # self.device.absolute("filtered_process_cpu", process.cpu, {"Process": key, "PID": str(process.pid)})
                self.device.absolute("filtered_process_group_cpu", process.cpu, {"Name": process.name, "Group": key, "PID": str(process.pid)})
                # self.device.absolute("filtered_process_size", process.res, {"Process": key, "PID": str(process.pid)})
                self.device.absolute("filtered_process_group_size", process.res, {"Name": process.name, "Group": key, "PID": str(process.pid)})

            log.debug(f"PID match check for pattern {key}: [current: {current_pids}, previous: {self.previous_pids.get(key, [])}]")
            if self.previous_pids.get(key, False):
                if current_pids != []:
                    pids_match = collections.Counter(current_pids) == collections.Counter(self.previous_pids[key])
                    self.device.absolute("filtered_process_pids_changed", 0 if pids_match else 1, {"Process": key})
                    self.previous_pids.update({key: current_pids})
                else:
                    pass
            elif not self.previous_pids.get(key, False):
                if current_pids != []:
                    self.previous_pids.update({key: current_pids})
                else:
                    pass

    @time_it(logging.DEBUG) 
    @exception_logger
    def get_uptime_via_ps(self):
        total_seconds = self.remote_host.run_ps_for_uptime()
        self.device.absolute("uptime", total_seconds)

    @time_it(logging.DEBUG) 
    @exception_logger
    def get_memory_via_svmon(self):
        result = self.remote_host.run_svmon()
        self.device.absolute("physical_memory_free", result.mem_free)
        self.device.absolute("physical_memory_used_percent", result.mem_used_percentage)
        self.device.absolute("swap_free", result.page_free)
        self.device.absolute("swap_used_percent", result.page_used_percentage)
        self.device.absolute("swap_free_percent", (100 - result.page_used_percentage))

    @time_it(logging.DEBUG) 
    @exception_logger
    def get_procs_via_prstat(self):
        # Some functionality commented out here as we collect filtered metrics a different way now. Preserved in case needed in future
        # patterns = self.config.get("process_filter", "").split("\n") if self.config.get("process_filter") else []
        patterns = []
        top_processes, filtered_processes = self.remote_host.run_prstat_for_procs(patterns=patterns)
        for count, process in enumerate(top_processes):
            self.device.absolute("top_process_cpu", process.cpu, {"Process": process.name, "PID": str(process.pid)})
            self.device.absolute("top_process_size", process.size, {"Process": process.name, "PID": str(process.pid)})
            count += 1
            if count >= 10:
                break 

        # for count, process in enumerate(filtered_processes):
        #     self.device.absolute("filtered_process_cpu", process.cpu, {"Process": process.name, "PID": str(process.pid)})
        #     self.device.absolute("filtered_process_size", process.size, {"Process": process.name, "PID": str(process.pid)})

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_swapinfo_for_mem(self):
        result = self.remote_host.run_swapinfo_for_memory()
        self.device.absolute("swap_free", result.free_mem)
        self.device.absolute("swap_used_percent", result.percent_mem)
        self.device.absolute("swap_free_percent", (100 - result.percent_mem))

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_sar_disks(self):
        disks: List[SarDisk] = self.remote_host.run_sar_for_disks()
        for disk in disks:
            self.device.absolute("disk_read_ops", disk.reads_sec, {"Disk": disk.name})
            self.device.absolute("disk_write_ops", disk.writes_sec, {"Disk": disk.name})

    @time_it(logging.DEBUG) 
    @exception_logger
    def run_and_send_swap(self):
        result = self.remote_host.get_swap_from_swap()
        self.device.absolute("swap_free", result.swap_available)
        self.device.absolute("swap_total", result.swap_total)
        self.device.absolute("swap_used_percent", result.swap_used_percentage)
        self.device.absolute("swap_free_percent", result.swap_free_percentage)

    @exception_logger
    def clean_up_configs(self):
        log.debug("Cleaning up text field configs.")
        text_field_configs = ['process_filter', 'mounts_to_include', 'mounts_to_exclude', 'additional_props']
        for config in text_field_configs:
            self.config[config] = self.config.get(config, "").rstrip('\n')        

def create_valid_key_from_text(key_text: str):
    key_text = key_text.replace("-----BEGIN OPENSSH PRIVATE KEY----- ", "")
    key_text = key_text.replace(" -----END OPENSSH PRIVATE KEY-----", "")
    key_text = re.split("\s+", key_text)
    key_text = "\n".join(key_text)
    key_text = f"-----BEGIN OPENSSH PRIVATE KEY-----\n{key_text}\n-----END OPENSSH PRIVATE KEY-----"
    return key_text

