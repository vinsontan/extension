from contextlib import contextmanager
import logging
import re
from tokenize import String
from typing import List, Optional, Dict
from enum import Enum
import time
from io import StringIO

import paramiko

default_log = logging.getLogger(__name__)

CONNECT_TIMEOUT = 20 # seconds
TOP_PROCESSES_COUNT = 10
COMMAND_REPORT_INTERVAL = 5 # some commands need you to specify an interval e.g. vmstat 1 2

def strip_ansi(text):
    ansi_escape = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -/]*[@-~]', flags=re.IGNORECASE)
    text = ansi_escape.sub('', text)
    return text 
    
def to_bytes(value: str) -> int:
    value = value.upper()
    if re.search(r'[bkmgtBKMGT]$', value):
        unit = value[-1]
        float_value = float(re.sub("B|K|M|G|T", "", value))
        if unit == "B":
            return float_value
        if unit == "M":
            return float_value * 10 ** 6
        if unit == "G":
            return float_value * 10 ** 9
        if unit == "T":
            return float_value * 10 ** 12
        return float_value * 10 ** 3
    else:
        return float(value)

def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]

class OS(Enum):
    SOLARIS = "Solaris"
    SUSE = "Suse"
    LINUX = "Generic Linux"
    RHEL = "RHEL"
    AIX = "AIX"
    CENTOS = "Centos"
    FREE_BSD = "FreeBSD"
    ORACLE_LINUX = "Oracle Linux"
    HP_UX = "HP-UX"
    MAC_OS = "MacOS"

# these aren't perfectly accurate names for the lists but mainly just say if we can use sysstat tools or if
# sources like /proc/stat etc... will be available (standard has these files)
STANDARD_LINUX = [OS.LINUX, OS.CENTOS, OS.RHEL, OS.SUSE, OS.ORACLE_LINUX]
PROPRIETARY_LINUX = [OS.SOLARIS, OS.AIX, OS.FREE_BSD, OS.HP_UX]

class Process:
    def __init__(
        self, pid: int, username: str, size: int, res: int, cpu: float, name: str,
    ):

        self.pid: int = pid
        self.username: str = username
        self.size: int = int(to_bytes(str(size)))
        self.res: int = int(to_bytes(str(res)))
        self.cpu: float = float(str(cpu).replace("%", ""))
        if "/" in name:
            self.name = name.split("/")[-1]
        else:
            self.name: str = name

class EtcReleaseResult:
        def __init__(self, lines: List[str]):
            """
            NAME="Ubuntu"
            VERSION="18.04.5 LTS (Bionic Beaver)"
            ID=ubuntu
            ID_LIKE=debian
            PRETTY_NAME="Ubuntu 18.04.5 LTS"
            VERSION_ID="18.04"
            HOME_URL="https://www.ubuntu.com/"
            SUPPORT_URL="https://help.ubuntu.com/"
            BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
            PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
            VERSION_CODENAME=bionic
            UBUNTU_CODENAME=bionic
            """

            if len(lines) == 1:
                self.pretty_name = lines[0]

            else:
                for line in lines:
                    if line.startswith("NAME"):
                        _, name = line.split("=")
                        name = name.replace('\"', '')
                    elif line.startswith("ID"):
                        _, id = line.split("=")
                        id = id.replace('\"', '')
                    elif line.startswith("PRETTY_NAME"):
                        _, pretty_name = line.split("=")
                        pretty_name = pretty_name.replace('\"', '')

                self.id = id
                self.name = name
                self.pretty_name = pretty_name

class WResult:
    def __init__(self, os: OS, line: str):
        match = re.search("(\d+)\susers?,\s+load\saverages?:\s([0-9\.]+),\s([0-9\.]+),\s([0-9\.]+)", line )
        self.user_count = int(match.group(1))
        self.load_average_1_min = float(match.group(2))
        self.load_average_5_min = float(match.group(3))
        self.load_average_15_min = float(match.group(4))

class MacVMStatResult:
    def __init__(self, paged_in: float, paged_out: float):
        self.paged_in = paged_in
        self.paged_out = paged_out

class VMStatResult:
    def __init__(self, os: OS, line: str, sys_mem: int):
        values = line.split()
        values = [float(n) for n in values]
        
        # vmstat returns memory stats in pages. Page size is 4096 bytes
        # To get an accurate memory reading we need to convert those pages to bytes

        if os == OS.HP_UX:
            """
                procs           memory                   page                              faults       cpu
            r     b     w      avm    free   re   at    pi   po    fr   de    sr     in     sy    cs  us sy id
            1     0     0  6284836  15063156    0    0     2    0     0    0     0   6050  22356   841   1  0 99
            """

            procs_r, procs_b, procs_w, \
            memory_avm, memory_fre, \
            page_re, page_at, page_pi, page_po, page_fr, page_de, page_sr, \
            faults_in, faults_sy, faults_cs, \
            cpu_us, cpu_sy, cpu_id = values

            self.cpu_user = cpu_us
            self.cpu_system = cpu_sy
            self.cpu_idle = cpu_id
            self.cpu_utilization = cpu_sy + cpu_us
            self.paged_in = page_pi
            self.paged_out = page_po
            self.waiting_processes = procs_w
            self.memory_active = (float(memory_avm)/256)*1048576 # MB pages to Bytes
            self.memory_free = (float(memory_fre)/256)*1048576 # MB pages to Bytes
            self.total_memory = sys_mem
            self.memory_used_percent = ((self.total_memory-self.memory_free)*100)/self.total_memory
            

        elif os == OS.FREE_BSD:
            """
            r   b   w   avm free    flt re  pi  po  fr  sr  in  sy  cs  us  sy  id
            """
            procs_r, procs_b, procs_w, \
            memory_avm, memory_fre, \
            page_flt, page_re, page_pi, page_po, page_fr, page_sr, \
            faults_in, faults_sy, faults_cs, \
            cpu_us, cpu_sy, cpu_id = values

            self.cpu_user = cpu_us
            self.cpu_system = cpu_sy
            self.cpu_idle = cpu_id
            self.cpu_utilization = cpu_sy + cpu_us
            self.paged_in = page_pi
            self.paged_out = page_po
            self.waiting_processes = procs_w
            '''
            self.memory_active = (float(memory_avm)/256)*1048576 # MB to Bytes
            self.memory_free = (float(memory_fre)/256)*1048576 # MB to Bytes
            '''
            self.memory_active = float(memory_avm) * 1000
            self.memory_free = float(memory_fre) * 1000
            self.total_memory = sys_mem
            self.memory_used_percent = ((self.total_memory-self.memory_free)*100)/self.total_memory

        elif len(values) == 22: # different versions have different outputs
            """
            kthr      memory            page            disk          faults      cpu
            r b w   swap  free  re  mf pi po fr de sr cd -- -- --   in   sy   cs us sy id
            0 0 0 6311184 2210160 17 100 0 0  0  0  0  2  0  0  0   73  163   58  5  6 89
            0 0 0 6235656 2128992 4 151 0  0  0  0  0  0  0  0  0  381  111  174  0  0 100 <--only this line gets passed to __init__
            """
            kthr_r, kthr_b, kthr_w, \
            memory_swap, memory_free, \
            page_re, page_mf, page_pi, page_po, page_fr, page_de, page_sr, page_cd, \
            _, _, _, \
            faults_in, faults_sy, faults_cs, \
            cpu_us, cpu_sy, cpu_id = values

            self.cpu_user = cpu_us
            self.cpu_system = cpu_sy
            self.cpu_idle = cpu_id
            self.cpu_utilization = cpu_sy + cpu_us
            self.paged_in = page_pi
            self.paged_out = page_po
            self.waiting_processes = kthr_w

            if os == OS.SOLARIS:
                self.memory_free = memory_free * 1000
                self.total_memory = sys_mem
                self.memory_used_percent = ((self.total_memory-self.memory_free)*100)/self.total_memory

        elif len(values) == 19:
            """
            kthr    memory              page              faults              cpu
            ----- ----------- ------------------------ ------------ -----------------------
            r  b   avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa    pc    ec
            1  0 218222 1807408   0   0   0   0    0   0   2  202 238  0  1 99  0  0.02   7.8
            2  0 218223 1807407   0   0   0   0    0   0   3  123 245  0  1 99  0  0.01   5.4
            """
            kthr_r, kthr_b, \
            memory_avm, memory_fre, \
            page_re, page_pi, page_po, page_fr, page_sr, page_cy, \
            faults_in, faults_sy, faults_cs, \
            cpu_us, cpu_sy, cpu_id, cpu_wa, cpu_pc, cpu_ec  = values

            self.cpu_user = cpu_us
            self.cpu_system = cpu_sy
            self.cpu_idle = cpu_id
            self.cpu_utilization = cpu_sy + cpu_us
            self.paged_in = page_pi
            self.paged_out = page_po
            self.waiting_processes = None

        elif len(values) == 17:
            """
            procs -----------memory---------- ---swap-- -----io---- -system-- ------cpu-----
            r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st
            1  0      0 5312688 162900 1422932    0    0   578   205    0  443  2  0 97  0  0
            0  0      0 5312680 162908 1422932    0    0     0    12    0  293  0  0 100  0  0 <--only this line gets passed to __init__

            """
            procs_r, procs_b, \
            memory_swpd, memory_free, memory_buff, memory_cache, \
            swap_si, swap_so, \
            io_bi, io_bo, \
            system_in, system_cs, \
            cpu_us, cpu_sy, cpu_id, cpu_wa, cpu_st = values

            self.cpu_user = cpu_us
            self.cpu_system = cpu_sy
            self.cpu_idle = cpu_id
            self.cpu_utilization = cpu_sy + cpu_us
            self.paged_in = swap_si # si and so used for historical reasons - pi and po would be more accurate
            self.paged_out = swap_so
            self.waiting_processes = None

        else:
            self._log.error(f"Unexpected number of values returned: {values}")

    def __repr__(self):
        val = []
        for attr in self.__dict__:
            val.append(f"{attr}={self.__dict__[attr]}")
        return ', '.join(val)
class Mount:
    def __init__(self, file_system: str, size: float, used: float, available: float, capacity: float, mounted_on: str):
        self.file_system: str = file_system
        self.size: float = size
        self.used: float = used
        self.available: float = available
        self.capacity: float = capacity
        self.used: float = used
        self.mounted_on: str = mounted_on

    @staticmethod
    def from_line(os: OS, line: str) -> "Mount":
        """
        $ df -h
        Filesystem             Size   Used  Available Capacity  Mounted on
        rpool/ROOT/solaris      30G   8.4G        13G    39%    /
        rpool/ROOT/solaris/var
                                30G   373M        13G     3%    /var
        /devices                 0K     0K         0K     0%    /devices
        """
        if os == OS.MAC_OS:
            file_system, size, used, available, capacity, iused, ifree, percent_iused, mounted_on, *_ = [value.strip() for value in line.split()]
        else:
            file_system, size, used, available, capacity, mounted_on = [value.strip() for value in line.split(maxsplit=7)]
            if os == OS.HP_UX:
                size = f"{size}K"
                used = f"{used}K"
                available = f"{available}K"
        return Mount(
            file_system, to_bytes(size), to_bytes(used), to_bytes(available), float(capacity.replace("%", "")), mounted_on
        )

    def __repr__(self):
        return f"Mount({self.file_system}:{self.mounted_on}, capacity: {self.capacity})"

class DFResult:
    def __init__(self, os: OS, lines: List[str]):
        self.mounts = []
        if os == OS.HP_UX:
            skip_next_line = False
            for index, line in enumerate(lines):
                if not line.startswith("Filesystem"):
                    if skip_next_line:
                        skip_next_line = False
                        continue
                    if len(line.split()) == 1:
                        line = f"{line} {lines[index + 1]}"
                        skip_next_line = True
                    self.mounts.append(Mount.from_line(os, line))
        else:
            for line in lines:
                if not line.startswith("Filesystem"):
                    self.mounts.append(Mount.from_line(os, line))

class MemInforesult:
    def __init__(self, os: OS, lines: List[str]):
        self.memory_total = None
        self.memory_available = None
        self.memory_free = None
        self.active_file = None
        self.inactive_file = None
        self.s_reclaimable = None
        self.swap_total = None
        self.swap_free = None

        for count, line in enumerate(lines):
            if line.startswith("MemTotal"):
                match = re.match("MemTotal:\s+(\d+)", line)
                self.memory_total = int(match.group(1)) * 1000
            elif line.startswith("MemAvailable"):
                match = re.match("MemAvailable:\s+(\d+)", line)
                self.memory_available = int(match.group(1)) * 1000
            elif line.startswith("MemFree"):
                match = re.match("MemFree:\s+(\d+)", line)
                self.memory_free = int(match.group(1)) * 1000
            elif line.startswith("Inactive(file)"):
                match = re.match("Inactive\(file\):\s+(\d+)", line)
                self.inactive_file = int(match.group(1)) * 1000
            elif line.startswith("Active(file)"):
                match = re.match("Active\(file\):\s+(\d+)", line)
                self.active_file = int(match.group(1)) * 1000
            elif line.startswith("SReclaimable"):
                match = re.match("SReclaimable:\s+(\d+)", line)
                self.s_reclaimable = int(match.group(1)) * 1000
            elif line.startswith("SwapTotal"):
                match = re.match("SwapTotal:\s+(\d+)", line)
                self.swap_total = int(match.group(1)) * 1000
            elif line.startswith("SwapFree"):
                match = re.match("SwapFree:\s+(\d+)", line)
                self.swap_free = int(match.group(1)) * 1000

        if self.swap_total > 0:
            self.swap_available_percent = (self.swap_free / self.swap_total) * 100
            self.swap_used_percent = 100 - self.swap_available_percent
        else:
            self.swap_available_percent = None
            self.swap_used_percent = None

        if self.memory_available is None:
            if self.memory_free and self.active_file and self.inactive_file and self.s_reclaimable:
                # https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/commit/?id=34e431b0ae398fc54ea69ff85ec700722c9da773
                self.memory_available = self.memory_free + self.active_file + self.inactive_file + self.s_reclaimable
            else:
                # Old versions might just have very basic info available
                self.memory_available = self.memory_free

        self.memory_available_percent = (self.memory_available / self.memory_total) * 100
        self.memory_used_percent = 100 - self.memory_available_percent

    def __repr__(self):
        val = []
        for attr in self.__dict__:
            val.append(f"{attr}={self.__dict__[attr]}")
        return ', '.join(val)

class IPInterface:
    def __init__(self, name: str, ipv4: str, bytes_received: int, packets_received: int, errors_incoming: int, packets_dropped_incoming: int,
        bytes_sent: int, packets_sent: int, errors_outgoing: int, packets_dropped_outgoing: int):
        self.name = name
        self.ipv4 = ipv4
        self.bytes_received: int = bytes_received
        self.packets_received: int = packets_received
        self.errors_incoming: int = errors_incoming
        self.packets_dropped_incoming: int = packets_dropped_incoming
        self.bytes_sent: int = bytes_sent
        self.packets_received: int = packets_received
        self.packets_sent: int = packets_sent
        self.errors_outgoing: int = errors_outgoing
        self.packets_dropped_outgoing: int = packets_dropped_outgoing
        
    def __repr__(self):
        val = []
        for attr in self.__dict__:
            val.append(f"{attr}={self.__dict__[attr]}")
        return ', '.join(val)

class IPResult:
    def __init__(self, os: OS, lines: List[str]):
        """
        1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
            link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
            inet 127.0.0.1/8 scope host lo
                valid_lft forever preferred_lft forever
            inet6 ::1/128 scope host
                valid_lft forever preferred_lft forever
            RX: bytes  packets  errors  dropped overrun mcast
            833773     11489    0       0       0       0
            TX: bytes  packets  errors  dropped carrier collsns
            833773     11489    0       0       0       0
        2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
            link/ether 00:15:5d:38:01:06 brd ff:ff:ff:ff:ff:ff
            inet 172.17.68.239/20 brd 172.17.79.255 scope global dynamic noprefixroute eth0
                valid_lft 72921sec preferred_lft 72921sec
            inet6 fe80::148e:b6f8:206d:aebe/64 scope link noprefixroute
                valid_lft forever preferred_lft forever
            RX: bytes  packets  errors  dropped overrun mcast
            2259480    9177     0       0       0       1323
            TX: bytes  packets  errors  dropped carrier collsns
            1935107    9656     0       0       0       0
        """
        self.interfaces: List[IPInterface] = []
        interface_start_pattern = re.compile("^\d+:\s([a-zA-Z0-9]+):")
        within_interface = False
        next_line_is_rx = False
        next_line_is_tx = False

        for line in lines:
            if not within_interface:
                first_line_match = interface_start_pattern.match(line)
                if first_line_match:
                    within_interface = True
                    name = first_line_match.group(1)
                    continue
            if within_interface:
                if line.startswith("inet "):
                    _, ipv4, *_ = line.split()
                    ipv4 = ipv4.split("/")[0]
                elif line.startswith("RX"):
                    next_line_is_rx = True
                elif next_line_is_rx:
                    bytes_received, packets_received, errors_incoming, packets_dropped_incoming, _, _ = line.split(maxsplit=6)
                    next_line_is_rx = False
                elif line.startswith("TX"):
                    next_line_is_tx = True
                elif next_line_is_tx:
                    bytes_sent, packets_sent, errors_outgoing, packets_dropped_outgoing, _, _ = line.split(maxsplit=6)
                    next_line_is_tx = False
                    within_interface = False
                    self.interfaces.append(IPInterface(name, ipv4, bytes_received, packets_received, errors_incoming, packets_dropped_incoming,
                        bytes_sent, packets_sent, errors_outgoing, packets_dropped_outgoing))

class ProcStatCpu:
    def __init__(self, id: str, user_time: int, nice_time: int, system_time: int, idle_time: int, iowait_time: int, irq_time: int, soft_irq_time: int):

        self.id: str = id
        self.user_time = user_time
        self.nice_time = nice_time
        self.system_time = system_time
        self.idle_time = idle_time
        self.iowait_time = iowait_time
        self.irq_time = irq_time
        self.soft_irq_time = soft_irq_time
        self.total_time = user_time + nice_time + system_time + idle_time + iowait_time + irq_time + soft_irq_time

    def from_line(line: str) -> "ProcStatCpu":
        """
        cpu0 17130 2247 8484 6344016 4715 0 756 0 0 0
        """
        cpu_id, user, nice, system, idle, iowait, irq, softirq, *_ = line.split()
        if cpu_id == "cpu":
            cpu_id = "OVERALL"
        else:
            cpu_id = re.match("cpu(\d+)", cpu_id).group(1)
        return ProcStatCpu(cpu_id, int(user), int(nice), int(system), int(idle), int(iowait), int(irq), int(softirq))

class UNameResult:
    def __init__(self, os: OS, lines: List[str]):
        """
        Linux ubuntu-dev 5.4.0-87-generic #98~18.04.1-Ubuntu SMP Wed Sep 22 10:45:04 UTC 2021 x86_64 x86_64 x86_64 GNU/Linux
        """
        self.kernel_name, self.hostname, self.kernel_version, *_ = lines[0].split()

class TopCpu:
    def __init__(self, id: str, user_percentage: float, sys_percentage: float, idle_percentage: float):
        self.id: str = id
        self.user_percentage: float = user_percentage
        self.sys_percentage: float = sys_percentage
        self.idle_percentage: float = idle_percentage

    def from_line(os: OS, line: str) -> "TopCpu":
        if os == OS.HP_UX:
            """
            CPU   LOAD   USER   NICE    SYS   IDLE  BLOCK  SWAIT   INTR   SSYS
            0    0.02   1.0%   0.0%   0.0%  99.0%   0.0%   0.0%   0.0%   0.0% <- this line
            """
            id, load, user, nice, sys, idle, block, swait, intr, ssys = line.split()
            return TopCpu(str(id), float(user.replace("%", "")), float(sys.replace("%", "")), float(idle.replace("%", "")))
        else:
            match = re.search(r'CPU (\d+):', line)
            if match:
                # must be multiple CPUs
                # CPU 0:  0.0% user,  0.0% nice,  0.0% system,  0.1% interrupt, 99.8% idle
                _, id, usr, _, nice, _, system, _, interrupt, _, idle, _ = line.split()
                return TopCpu(str(id), float(usr.replace("%", "")), float(system.replace("%", "")), float(idle.replace("%", "")))
            elif line.startswith("CPU:"):
                # CPU:  0.0% user,  0.0% nice,  0.0% system,  0.1% interrupt, 99.8% idle
                _, usr, _, nice, _, system, _, interrupt, _, idle, _ = line.split()
                return TopCpu(0, float(usr.replace("%", "")), float(system.replace("%", "")), float(idle.replace("%", "")))

    def __repr__(self):
        val = []
        for attr in self.__dict__:
            val.append(f"{attr}={self.__dict__[attr]}")
        return ', '.join(val)
        
class MPStatCPU:
    def __init__(self, id: str, user_percentage: float, sys_percentage: float, idle_percentage: float):
        self.id: str = id
        self.user_percentage: float = user_percentage
        self.sys_percentage: float = sys_percentage
        self.idle_percentage: float = idle_percentage

    def from_line(os: OS, line: str) -> "MPStatCPU":
        if os == OS.SOLARIS:
            """ 0   22   0    0   394  142  274   29    0   30    0    45    0   2   0  98 """
            id, minf, mjf, xcal, intr, ithr, csw, icsw, migr, smtx, srw, syscl, usr, sys, st, idl = line.split()
            return MPStatCPU(id, float(usr), float(sys), float(idl))

        if os == OS.AIX:
            """
            cpu  min  maj  mpc  int   cs  ics   rq  mig lpa sysc us sy wa id   pc  %ec  lcs
            0    8    0    0  142   78    0    1    0 100   87 14 47  0 39 0.00  1.3  114 <-- this line
            """
            cpu, _, _, _, _, _, _, _, _, _, _, us, sy, wa, idle, _, _, _ = line.split()
            return MPStatCPU(cpu, float(us), float(sy), float(idle))

class MPStatResult:
    def __init__(self, os: OS, lines: List[str]):
        self.cpus: List[MPStatCPU] = []
        if os == OS.SOLARIS:
            """
            CPU minf mjf xcal  intr ithr  csw icsw migr smtx  srw syscl  usr sys  st idl
            0 1337   0    0   442  173 1402  139    0   24    0  4224    2   5   0  92
            1   22   0    0   394  142  274   29    0   30    0    45    0   2   0  98
            CPU minf mjf xcal  intr ithr  csw icsw migr smtx  srw syscl  usr sys  st idl <- this is the table we care about
            0 1337   0    0   442  173 1402  139    0   24    0  4224    2   5   0  92
            1   22   0    0   394  142  274   29    0   30    0    45    0   2   0  98
            """
            if len(lines) == 3: # only one CPU so only one header/table printed with second row being current interval
                self.cpus.append(MPStatCPU.from_line(os, lines[2]))
            else:
                header_found = False
                current_values_table = False
                for line in lines:
                    if line.startswith("CPU"):
                        header_found = True
                    elif header_found:
                        if line.startswith("CPU"):
                            current_values_table = True
                        elif current_values_table:
                            self.cpus.append(MPStatCPU.from_line(line))

        elif os == OS.AIX:
            """
            cpu  min  maj  mpc  int   cs  ics   rq  mig lpa sysc us sy wa id   pc  %ec  lcs
            0    8    0    0  124   78    0    1    0 100   85 16 49  0 35 0.00  1.8   96
            1    0    0    0    6    0    0    0    0   -    0  0  2  0 98 0.00  1.2    6
            2    0    0    0    6    0    0    0    0   -    0  0  6  0 94 0.00  0.7    6
            """
            header_found = False
            for line in lines:
                if line.startswith("cpu"):
                    header_found = True
                    continue
                elif header_found:
                    if line.startswith("U"):
                        break
                    else:
                        self.cpus.append(MPStatCPU.from_line(os, line))
             
                        # self.cpus.append(MPStatCPU.from_line(line))


class ProcStatResult:
    def __init__(self, os: OS, lines: List[str]):
        """
        cpu  17130 2247 8484 6344016 4715 0 756 0 0 0
        cpu0 17130 2247 8484 6344016 4715 0 756 0 0 0
        intr 345 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
        ctxt 20243630
        btime 1633443740
        processes 30798
        procs_running 3
        procs_blocked 0
        softirq 3190071 0 2135813 257 124392 122849 0 159798 0 8 646954
        """
        self.cpus: Dict[ProcStatCpu] = {}
        for line in lines:
            if line.startswith("cpu"):
                cpu = ProcStatCpu.from_line(line)
                self.cpus.update({cpu.id: cpu})
                # self.cpus.append(ProcStatCpu.from_line(line))
            elif line.startswith("btime"):
                _, boot_time = line.split()
                self.uptime_seconds = time.time() - float(boot_time)
            elif line.startswith("procs_blocked"):
                _, procs_blocked = line.split()
                self.procs_blocked = int(procs_blocked)

class Disk:
    def __init__(
        self, device: str, bytes_read: int, bytes_written: int, bytes_per_transfer: float = 0, transfers_per_second: float = 0, bytes_per_second: float = 0
    ):
        self.device = device
        self.bytes_read = bytes_read
        self.bytes_written = bytes_written
        self.bytes_per_transfer = bytes_per_transfer
        self.transfers_per_second = transfers_per_second
        self.bytes_per_second = bytes_per_second

    @staticmethod
    def from_line(os: OS, line: str) -> "Disk":
        if os == OS.FREE_BSD:
            """
                                    extended device statistics
            device           r/i         w/i         kr/i         kw/i qlen   tsvc_t/i      sb/i
            da0           1224.0      4336.0      23304.0      32976.0    0        2.2       1.4
            da1             29.0         0.0        522.0          0.0    0        0.0       0.0
            """
            device, reads, writes, bytes_read, bytes_written, *_ = line.split()
            bytes_read = to_bytes(f"{bytes_read}K")
            bytes_written = to_bytes(f"{bytes_written}K")
            return Disk(device, bytes_read, bytes_written)

        elif os == OS.SOLARIS:
            """
            extended device statistics
            device,r/i,w/i,kr/i,kw/i,wait,actv,wsvc_t,asvc_t,%w,%b,
            cmdk0,37426.0,1469569.0,553364.5,7728704.5,0.0,0.0,1.1,0.7,1,1
            cmdk1,11.0,0.0,5.5,0.0,0.0,0.0,0.0,0.1,0,0

            device,r/i,w/i,kr/i,kw/i,wait,actv,svc_t,%w,%b
            sd0,215203436.0,940028069.0,21843898223.2,924333700.0,0.0,0.0,0.2,0,0        
            """
            device, reads, writes, bytes_read, bytes_written, *_ = [l.strip() for l in line.split(",")]
            bytes_read = to_bytes(f"{bytes_read}K")
            bytes_written = to_bytes(f"{bytes_written}K")
            return Disk(device, bytes_read, bytes_written)

        elif os == OS.AIX:
            """
            System configuration: lcpu=8 drives=2 paths=1 vdisks=1

            Disks:         % tm_act     Kbps      tps    Kb_read   Kb_wrtn
            cd0               0.0       0.0       0.0         88         0
            hdisk0            0.0       0.0       0.0     289870    146412
            """
            device, tm_act, kbps, tps, kb_read, kb_written = line.split()
            bytes_read = to_bytes(f"{kb_read}K")
            bytes_written = to_bytes(f"{kb_written}K")
            return Disk(device, bytes_read, bytes_written)
        
        elif os in STANDARD_LINUX:
            """
            Linux 5.4.0-87-generic (ubuntu-dev)     10/13/2021      _x86_64_        (1 CPU)

            Device             tps    kB_read/s    kB_wrtn/s    kB_read    kB_wrtn
            loop0             0.00         0.01         0.00         46          0
            sda               2.69        76.42        27.84     698761     254557
            """
            device, tps, _, _, bytes_read, bytes_written = [l.strip() for l in line.split()]
            bytes_read = to_bytes(f"{bytes_read}K")
            bytes_written = to_bytes(f"{bytes_written}K")
            return Disk(device, bytes_read, bytes_written)

    def __repr__(self):
        val = []
        for attr in self.__dict__:
            val.append(f"{attr}={self.__dict__[attr]}")
        return ', '.join(val)
        
class SvMonResult:
    def __init__(self, os: OS, lines: List[str]):
        """
        Unit: KB
        --------------------------------------------------------------------------------------
                    size       inuse        free         pin     virtual  available   mmode
        memory      8388608     1162508     7226100      467040      875340    7391932   Ded-E
        pg space   10485760        5960
        """
        for line in lines:
            if line.startswith("memory"):
                _, size, inuse, free, *_ = line.split()
                self.mem_size: int = to_bytes(f"{int(size)*4}K")
                self.mem_in_use: int = to_bytes(f"{int(inuse)*4}K")
                self.mem_free: int = to_bytes(f"{int(free)*4}K")
                self.mem_used_percentage: float = (self.mem_in_use / self.mem_size) * 100
            elif line.startswith("pg space"):
                _, _, size, inuse = line.split()
                self.page_size: int = to_bytes(f"{int(size)*4}K")
                self.page_in_use: int = to_bytes(f"{int(inuse)*4}K")
                self.page_free: int = self.page_size - self.page_in_use
                self.page_used_percentage: float = (self.page_in_use / self.page_size) * 100
                break

class IOStatResult:
    def __init__(self, os: OS, lines: List[str]):
        self.disks: List[Disk] = []
        capture = False
        if os == OS.MAC_OS:
            disk_names = []
            value_sublists = []
            for index, line  in enumerate(lines):
                if index == 0:
                    disk_names = line.split()
                elif index == 3:
                    values = line.split()
                    for i in range(0, len(values), 3):
                        value_sublists.append(values[i:i+3])
            for index, values in enumerate(value_sublists):
                self.disks.append(Disk(disk_names[index], 0, 0, to_bytes(f"{values[0]}K"), values[1], to_bytes(f"{values[2]}M")))

        elif os == OS.FREE_BSD:
            for line in lines:
                if capture:
                    self.disks.append(Disk.from_line(os, line))
                if line.startswith("device"):
                    capture = True

        elif os == OS.SOLARIS:
            for line in lines:
                if capture:
                    self.disks.append(Disk.from_line(os, line))
                if line.startswith("device,"):
                    capture = True

        elif os == OS.AIX:
            for line in lines:
                if capture:
                    self.disks.append(Disk.from_line(os, line))
                if line.startswith("Disks"):
                    capture = True

        elif os in STANDARD_LINUX:
            for line in lines:
                if capture:
                    if line.startswith("loop"): # skip loop devices
                        continue
                    self.disks.append(Disk.from_line(os, line))
                if line.startswith("Device"):
                    capture = True        

class SwapInfoResult:
    def __init__(self, os: OS, lines: List[str]):
        """
                         Mb          Mb           Mb   PCT      START/          Mb
        TYPE          AVAIL        USED         FREE  USED       LIMIT     RESERVE  PRI  NAME
        dev           32768           0        32768    0%           0           -    1  /dev/vg00/lvol2
        reserve           -       25474       -25474
        memory        93389       10353        83036   11%
        total        126157       35827        90330   28%       -           0    -
        """
        for line in lines:
            if line.startswith("total"):
                _, total_mem, used_mem, free_mem, percent_mem, *_ = line.split()
                self.total_mem = to_bytes(f"{total_mem}M")
                self.used_mem = to_bytes(f"{used_mem}M")
                self.free_mem = to_bytes(f"{free_mem}M")
                self.percent_mem = to_bytes(f"{percent_mem[:-1]}")

class SarDisk:
    def __init__(self, os: OS, line: str):
        """
        13:53:31    disk1    4.59    2.13       0       8      77   14.98   29.13
        """
        _, name, busy_percent, avque, reads_sec, writes_sec, blocks_sec, avwait, avserv = line.split()
        self.name = name
        self.busy_percent = float(busy_percent)
        self.avque = float(avque)
        self.reads_sec = float(reads_sec)
        self.writes_sec = float(writes_sec)
        self.blocks_sec = float(blocks_sec)
        self.avwait = float(avwait)
        self.avserv = float(avserv)

class SwapResult:
    def __init__(self, os: OS, line: str):
        '''
        total: 405232k bytes allocated + 143200k reserved = 548432k used, 4188044k available
        '''
        matches = re.findall(r"([\d]+[a-z]?)", line)
        self.swap_allocated = to_bytes(matches[0])
        self.swap_reserved = to_bytes(matches[1])
        self.swap_used = to_bytes(matches[2])
        self.swap_available = to_bytes(matches[3])
        self.swap_total = self.swap_used + self.swap_available
        if self.swap_total > 0:
            self.swap_used_percentage = (self.swap_used / self.swap_total) * 100
            self.swap_free_percentage = 100 - self.swap_used_percentage



class TopResult:
    def __init__(self, os: OS, lines: List[str], process_limit: int = TOP_PROCESSES_COUNT):
        self.processes = []
        self.cpus: List[TopCpu] = []

        if os == OS.HP_UX:
            process_lines_started = False
            cpu_lines_started = False
            for line in lines:
                if line.startswith("CPU   LOAD"):
                    """
                    CPU   LOAD   USER   NICE    SYS   IDLE  BLOCK  SWAIT   INTR   SSYS
                    0    0.02   1.0%   0.0%   0.0%  99.0%   0.0%   0.0%   0.0%   0.0%
                    1    0.01   1.0%   0.0%   1.0%  98.0%   0.0%   0.0%   0.0%   0.0%
                    """
                    cpu_lines_started = True
                elif cpu_lines_started and line.startswith("---"):
                    cpu_lines_started = False
                elif cpu_lines_started:
                    self.cpus.append(TopCpu.from_line(os, line))
                elif line.startswith("CPU TTY"):
                    process_lines_started = True
                elif process_lines_started:
                    """
                    CPU TTY  PID USERNAME PRI NI   SIZE    RES STATE    TIME %WCPU  %CPU COMMAND
                    15   ? 14326 root     152 20 57260K 23936K run   9274:34  2.04  2.04 BESClient <-
                    """
                    cpu_id, _, pid, username, pri, ni, size, res, state, time, wcpu, cpu, command = line.split()
                    pid = int(pid)
                    size = to_bytes(size)
                    res = to_bytes(res)
                    wcpu = float(wcpu.replace("%", ""))
                    self.processes.append(Process(pid, username, size, res, wcpu, command))

        elif os == OS.FREE_BSD:
            process_lines_started = False
            number_of_values = 0
            for line in lines:
                if line.startswith("CPU"):
                    self.cpus.append(TopCpu.from_line(os, line))
                elif line.startswith("Swap:"):
                    """
                    Swap: 2048M Total, 2048M Free
                    """
                    _, total_swap, _, free_swap, _ = line.split()
                    self.total_swap = to_bytes(total_swap)
                    self.free_swap = to_bytes(free_swap)
                    self.swap_utilized = ((self.total_swap - self.free_swap) / self.total_swap) * 100
                elif line.startswith("PID"):
                    process_lines_started = True
                    number_of_values = len(line.split())
                    continue
                elif process_lines_started:
                    """
                    PID USERNAME    THR PRI NICE   SIZE    RES STATE    C   TIME    WCPU COMMAND
                    1258 root          1  20    0    11M  1496K select   0   0:00   0.00% devd
                    """
                    if number_of_values == 12:
                        pid, username, thr, pri, nice, size, res, state, c, time, wcpu, command = line.split()
                    elif number_of_values == 11:
                        pid, username, pri, nice, size, res, state, c, time, wcpu, command = line.split()
                    pid = int(pid)
                    command = command.split("/")[0]
                    size = to_bytes(size)
                    res = to_bytes(res)
                    wcpu = float(wcpu.replace("%", ""))
                    self.processes.append(Process(pid, username, size, res, wcpu, command))


        elif os == OS.SOLARIS:
            process_lines_started = False
            for count, line in enumerate(lines):
                if count == 4:
                    """
                    Memory: 4096M phys mem, 2223M free mem, 4096M total swap, 4096M free swap
                    """
                    _, phys_mem, _, _, free_mem, _, _, total_swap, _, _, free_swap, _, _ = line.split()
                    self.phys_mem = to_bytes(phys_mem)
                    self.free_mem = to_bytes(free_mem)
                    self.total_swap = to_bytes(total_swap)
                    self.free_swap = to_bytes(free_swap)
                    self.phys_mem_utilized = ((self.phys_mem - self.free_mem) / self.phys_mem) * 100
                    self.swap_utilized = ((self.total_swap - self.free_swap) / self.total_swap) * 100
                elif line.startswith("PID"):
                    process_lines_started = True
                    continue
                elif process_lines_started:
                    """
                    PID USERNAME NLWP PRI NICE  SIZE   RES STATE     TIME    CPU COMMAND
                    1448 vagrant     1  59    0 4704K 2756K cpu       0:00  0.44% top
                    """                 
                    pid, username, nlwp, pri, nice, size, res, state, time, cpu, command = line.split()
                    pid = int(pid)
                    command = command.split("/")[0]
                    size = to_bytes(size)
                    res = to_bytes(res)
                    cpu = float(cpu.replace("%", ""))

                    self.processes.append(Process(pid, username, size, res, cpu, command))
        
        elif os == OS.MAC_OS:
            second_page_started = False
            process_lines_started = False
            for index, line in enumerate(lines):
                if not second_page_started:
                    if line.startswith("Processes:") and index > 0:
                        second_page_started = True
                        continue
                elif second_page_started:
                    if line.startswith("CPU usage:"):
                        _, _, user, _, sys, _, idle, _ = line.split()
                        self.cpu_user = float(user.replace("%", ""))
                        self.cpu_sys = float(sys.replace("%", ""))
                        self.cpu_idle = float(idle.replace("%", ""))
                        self.cpu_utilization = 100 - self.cpu_idle
                    elif line.startswith("PhysMem:"):
                        used_match = re.search(r'(\d+[a-zA-Z])?\sused', line)
                        self.phys_mem_used = to_bytes(used_match.group(1))
                        unused_match = re.search(r'(\d+[a-zA-Z])?\sunused', line)
                        self.phys_mem_unused = to_bytes(unused_match.group(1))

                        self.phys_mem = self.phys_mem_used + self.phys_mem_unused
                        self.memory_used_percent = (self.phys_mem_used / self.phys_mem) * 100

                    elif line.startswith("Swap:"):
                        _, used, _, free, *_ = line.split()
                        self.free_swap = to_bytes(free)
                        self.used_swap = to_bytes(used)
                        self.swap_utilized = (self.used_swap / (self.used_swap + self.free_swap)) * 100
                    elif line.startswith("PID"):
                        process_lines_started = True
                        continue
                    elif process_lines_started:
                        pid, command, cpu, mem = line.split()
                        self.processes.append(Process(pid, "", mem.replace("+", "").replace("-", ""), mem.replace("+", "").replace("-", ""), cpu, command))
        elif os in STANDARD_LINUX:
            process_count = 0
            process_lines_started = False
            for line in lines:
                if line.startswith("PID"):
                    process_lines_started = True
                    continue
                elif process_lines_started:
                    """
                    PID USER      PR  NI    VIRT    RES    SHR S %CPU %MEM     TIME+ COMMAND
                    1 root      20   0  163004   9952   7136 S  0.0  0.1   0:00.77 systemd
                    2 root      20   0       0      0      0 S  0.0  0.0   0:00.00 kthreadd
                    3 root       0 -20       0      0      0 I  0.0  0.0   0:00.00 rcu_gp
                    57160 root      20   0   24.9g 865688  18164 S   0.0  1.3  27:39.82 java <-- must account for units in sizes
                    """
                    try:
                        pid, user, pr, no, virt, res, shr, s, cpu, mem, _, command = line.split()
                        pid = int(pid)
                        command = command.split("/")[0]
                        virt = to_bytes(virt)
                        res = to_bytes(res)
                        shr = to_bytes(shr)
                        cpu = float(cpu.replace("%", ""))

                        self.processes.append(Process(pid, user, virt, res, cpu, command))
                        process_count += 1
                        if process_count >= process_limit:
                            break
                    except Exception as e:
                        default_log.warning(f"Bad process line: '{line}'. Error: {e}")
                        
    def __repr__(self):
        val = []
        for attr in self.__dict__:
            val.append(f"{attr}={self.__dict__[attr]}")
        return ', '.join(val)
        
class Interface:
    def __init__(
        self, name: str, network: str, address: str, in_packets: int, in_errors: int, out_packets: int, out_errors: int, collisions: int
    ):
        self.name: str = name
        self.network: str = network
        self.address: str = address
        self.in_packets: int = in_packets
        self.in_errors: int = in_errors
        self.out_packets: int = out_packets
        self.out_errors: int = out_errors
        self.collisions: int = collisions

    @staticmethod
    def from_line(line) -> "Interface":
        """
        Name  Mtu  Net/Dest      Address        Ipkts  Ierrs Opkts  Oerrs Collis Queue
        lo0   8232 127.0.0.0     127.0.0.1      285878 0     285878 0     0      0
        net0  1500 10.0.2.0      10.0.2.15      901    0     1810   0     0      0
        net1  1500 192.168.15.0  192.168.15.222 43735  0     34059  0     0      0

        Name  Mtu  Net/Dest                    Address                     Ipkts  Ierrs Opkts  Oerrs Collis
        lo0   8252 ::1                         ::1                         285878 0     285878 0     0
        net0  1500 fe80::a00:27ff:fef7:9b0b/10 fe80::a00:27ff:fef7:9b0b    901    0     1810   0     0
        net1  1500 default                     ::                          43735  0     34063  0     0
        
        Name  Mtu   Network     Address            Ipkts Ierrs    Opkts Oerrs  Coll
        en0   1500  link#2      fa.7c.6b.2e.b0.20    65234     0    23753     0     0
        en0   1500  10.102.40   10.102.42.32        65234     0    23753     0     0
        lo0   16896 link#1                           3798     0     3798     0     0
        lo0   16896 127         127.0.0.1            3798     0     3798     0     0
        lo0   16896 ::1%1                            3798     0     3798     0     0

        Iface       MTU Met    RX-OK RX-ERR RX-DRP RX-OVR    TX-OK TX-ERR TX-DRP TX-OVR Flg
        eth0       1500   0     1062      0      0      0      960      0      0      0 BMRU
        lo        16436   0      941      0      0      0      941      0      0      0 LRU
        """
        values = line.split()
        if len(values) == 9:
            name, _, network, address, in_packets, in_errors, out_packets, out_errors, collisions = [
                l.strip() for l in line.split(maxsplit=9)
            ]

            if name.startswith("utun"):
                raise Exception(f"Skipping system virtual interface {name}")

        elif len(values) == 10:
            name, _, network, address, in_packets, in_errors, out_packets, out_errors, collisions, queue = [
                l.strip() for l in line.split(maxsplit=10)
            ]

        # RHEL
        elif len(values) == 12:
            name, _, _, in_packets, in_errors, in_dropped, rx_ovr, out_packets, out_errors, out_dropped, tx_ovr, flg = [
                l.strip() for l in line.split(maxsplit=12)
            ]
            address = ""
            network = ""
            collisions = 0
        
        else:
            raise Exception(f"Line not processed due to missing columns.")

        return Interface(name, network, address, int(in_packets if in_packets != "-" else 0), int(in_errors if in_errors != "-" else 0), int(out_packets if out_packets != "-" else 0), int(out_errors if out_errors != "-" else 0), int(collisions if collisions != "-" else 0))


class RemoteHost:
    def __init__(
        self, os: OS, hostname: str, username: str, port=22, password: Optional[str] = None, private_key_path=None, private_key_contents=None, private_key_password=None, disable_rsa2=False, log=default_log, custom_path: str = None
    ):
        self.os = os
        self.hostname = hostname
        self.username = username
        self.password = password
        self.port = port

        self._log = log
        self._private_key_path = private_key_path
        self._private_key_contents = private_key_contents
        self._private_key_password = private_key_password
        self._client = paramiko.SSHClient()
        self._client.load_system_host_keys()
        self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        self._disable_rsa2 = disable_rsa2
        self.custom_path: str = custom_path

    def run_command(self, cmd: str) -> List[str]:

        if self.custom_path:
            cmd = f"PATH={self.custom_path} {cmd}"

        self._log.debug(f"{self.hostname} - attempting to execute command '{cmd}'")
        try:
            stdin, stdout, stderr = self._client.exec_command(cmd, timeout=30)
            err = stderr.read().decode("utf-8")
            out = strip_ansi(stdout.read().decode("utf-8").replace("\x1b[6C", " "))
            self._log.debug(f"{self.hostname} - CMD: '{cmd}', stderr: '{err}'")
            lines = [l.strip() for l in out.splitlines() if l.strip()]
            self._log.debug(f"{self.hostname} - lines: {lines}")
            return lines
        except Exception as e:
            self._log.exception(f"{self.hostname} - error running command '{cmd}': {e}")
            return []

    @contextmanager
    def connect(self):
        if self._private_key_contents or self._private_key_path:
            private_key: paramiko.RSAKey = None
            if self._private_key_contents:
                self._log.info(f"{self.hostname} - attempting to connect using key contents, port: {self.port}, username: {self.username}")
                private_key = paramiko.RSAKey.from_private_key(StringIO(self._private_key_contents), password=self._private_key_password)
            else:
                self._log.info(f"{self.hostname} - attempting to connect using key file {self._private_key_path}, port: {self.port}, username: {self.username}")
                private_key = paramiko.RSAKey.from_private_key_file(self._private_key_path, password=self._private_key_password)
            if self._disable_rsa2:
                self._log.debug(f"Per configuration, connecting with RSA2 disabled.")
                self._client.connect(
                    self.hostname, port=self.port, username=self.username, pkey=private_key, passphrase=self._private_key_password, disabled_algorithms=dict(pubkeys=["rsa-sha2-512", "rsa-sha2-256"]), timeout=CONNECT_TIMEOUT
                )
            else:
                self._client.connect(
                    self.hostname, port=self.port, username=self.username, pkey=private_key, passphrase=self._private_key_password, timeout=CONNECT_TIMEOUT
                )
        else:
            self._log.info(f"{self.hostname} - attempting to connect using password, port: {self.port}, username: {self.username}")
            self._client.connect(self.hostname, port=self.port, username=self.username, password=self.password, timeout=CONNECT_TIMEOUT)
        yield self._client
        if self._client:
            self._client.close()
            self._log.info(f"{self.hostname} - disconnecting")

    def connect_for_persisted_connection(self):
        if self._private_key_contents or self._private_key_path:
            private_key: paramiko.RSAKey = None
            if self._private_key_contents:
                self._log.info(f"{self.hostname} - attempting to connect with persisted connection using key contents, port: {self.port}, username: {self.username}")
                private_key = paramiko.RSAKey.from_private_key(StringIO(self._private_key_contents), password=self._private_key_password)
            else:
                self._log.info(f"{self.hostname} - attempting to connect with persisted connection using key file {self._private_key_path}, port: {self.port}, username: {self.username}")
                private_key = paramiko.RSAKey.from_private_key_file(self._private_key_path, password=self._private_key_password)
            if self._disable_rsa2:
                self._log.debug(f"Per configuration, connecting with RSA2 disabled.")
                self._client.connect(
                    self.hostname, port=self.port, username=self.username, pkey=private_key, passphrase=self._private_key_password, disabled_algorithms=dict(pubkeys=["rsa-sha2-512", "rsa-sha2-256"]), timeout=CONNECT_TIMEOUT
                )
            else:
                self._client.connect(
                    self.hostname, port=self.port, username=self.username, pkey=private_key, passphrase=self._private_key_password, timeout=CONNECT_TIMEOUT
                )
        else:
            self._log.info(f"{self.hostname} - attempting to connect using password with persisted connection, port: {self.port}, username: {self.username}")
            self._client.connect(self.hostname, port=self.port, username=self.username, password=self.password, timeout=CONNECT_TIMEOUT)

    @contextmanager
    def reuse_connection(self):
        yield self._client

    def disconnect(self):
        if self._client:
            self._client.close()
            self._log.info(f"{self.hostname} - disconnecting")

    def run_vm_stat(self):
        lines = self.run_command(f"vm_stat | grep Page")
        for line in lines:
            if line.startswith("Pageins:"):
                _, pageins = line.split()
            elif line.startswith("Pageouts:"):
                _, pageouts = line.split()
        return MacVMStatResult(float(pageins.replace(".", "")), float(pageouts.replace(".", "")))

    def run_vmstat(self):
        command = f"vmstat {COMMAND_REPORT_INTERVAL} 2"
        sys_mem = None
        #lines = ['procs           memory                   page                              faults       cpu', 'r     b     w      avm    free   re   at    pi   po    fr   de    sr     in     sy    cs  us sy id', '1     1     0  1292289  370218    0    0     0    2     0    0     1   8747  67468  6209  10  7 83', '1     1     0  1292289  368192    0    0     0    0     0    0     0   3385  30433  1374   3  7 89']

        if self.os == OS.FREE_BSD:
            command = f"vmstat -H -n 0 {COMMAND_REPORT_INTERVAL} 2"
            sys_mem = self.get_freebsd_system_memory()
        elif self.os == OS.HP_UX:
            sys_mem = self.get_hpux_system_memory()
        elif self.os == OS.SOLARIS:
            sys_mem = self.get_solaris_system_memory()
            
        if self.os == OS.AIX:
            values_line_index = 5
        else:
            values_line_index = 3
        
            
        #for count, line in enumerate(lines):
        for count, line in enumerate(self.run_command(command)):
            if count == values_line_index:
                result = VMStatResult(self.os, line=line, sys_mem=sys_mem)

        return result
        

    def run_top_for_top_procs(self, threads_mode: bool = False):
        lines = []
        if self.os == OS.HP_UX:
            lines = self.run_command(f"export TERM=vt100; top -d 1")
        elif self.os == OS.FREE_BSD:
            lines = self.run_command(f"top {'-H' if threads_mode else ''} -Pb {TOP_PROCESSES_COUNT}")
        elif self.os == OS.MAC_OS:
            lines = self.run_command(f" top -n {TOP_PROCESSES_COUNT} -l 2 -s 5 -stats pid,command,cpu,mem -a -S -F")
        elif self.os == OS.SOLARIS:
            lines = [line for line in self.run_command(f"top {'-H' if threads_mode else ''} -b {TOP_PROCESSES_COUNT}")]
        elif self.os in STANDARD_LINUX:
            lines = self.run_command(f"top {'-H' if threads_mode else ''} -b -n 1")
        result = TopResult(self.os, lines)
        return result

    # Solaris
    def run_prstat_for_procs(self, sort_by="cpu", patterns: Optional[List[str]] = []):
        top_processes = []
        filtered_process_pids = []
        filtered_processes = []

        for pattern in patterns:
            filtered_process_pids.extend([p for p in self.run_command(f"pgrep -f {pattern}")])

        process_line = True
        for line in self.run_command(f"prstat -n 100 -c -Z -s {sort_by} {COMMAND_REPORT_INTERVAL} 1"):
            line = line.strip()
            if "please wait" in line.lower():
                continue
            if line.startswith("PID"):
                continue
            elif line.startswith("ZONEID"):
                process_line = False
                continue
            elif line.startswith("Total"):
                continue

            if process_line:
                pid, username, size, rss, state, pri, nice, time, cpu, name = [str(l.strip()) for l in line.split(maxsplit=9)]
                process = Process(pid, username, size, rss, cpu, name.split("/")[0])
                top_processes.append(process)

                if process.pid in filtered_process_pids:
                    filtered_processes.append(process)

        return top_processes, filtered_processes

    def get_filtered_procs_via_pgrep_and_top(self, threads_mode: bool = False, patterns: dict = {}):
        result_dict: dict[Process] = {}
        for key in patterns:
            result_dict.update({key: []})
            pids = []
            filtered_processes: List[Process] = []
            regex = patterns[key]
            pids.extend([p for p in self.run_command(f"pgrep -f {regex}")])
            for batch in chunks(pids, 20): # up two 20 pids can be specified in top filter
                result = TopResult(self.os, self.run_command(f"top {'-H' if threads_mode else ''} -b -n 1 -p {','.join(batch)}"), 20)
                filtered_processes.extend(result.processes)
                result_dict.update({key: filtered_processes})
        return result_dict
        
    def run_w(self):
        lines =  [line for line in self.run_command("w | head -n 1")]
        result = WResult(self.os, lines[0])
        return result

    def run_df(self):
        if self.os == OS.HP_UX:
            lines = [line for line in self.run_command("bdf")]
        if self.os == OS.MAC_OS:
            lines = [line for line in self.run_command("df -Hl")]
        else:
            lines = [line for line in self.run_command("df -Ph")]
        result = DFResult(self.os, lines)
        return result

    def run_cat_proc_stat(self):
        lines = self.run_command("cat /proc/stat")
        result = ProcStatResult(self.os, lines)
        return result

    def run_cat_proc_meminfo(self):
        lines = self.run_command("cat /proc/meminfo")
        result = MemInforesult(self.os, lines)
        return result

    def run_ip(self):
        lines = self.run_command("ip -s a")
        if lines == []: # likely need to try specifying full command path
            lines = self.run_command("/usr/sbin/ip -s a")
        result = IPResult(self.os, lines)
        return result

    def run_uname(self):
        lines = self.run_command("uname -a")
        result = UNameResult(self.os, lines)
        return result

    def run_iostat(self):
        if self.os == OS.FREE_BSD:
            lines = self.run_command("iostat -Ixt da")
        elif self.os in STANDARD_LINUX or self.os == OS.AIX:
            lines = self.run_command("iostat -d")
        elif self.os == OS.SOLARIS:
            lines = self.run_command("iostat -rxI")
        elif self.os == OS.MAC_OS:
            lines = self.run_command("iostat -c 2 -d -I -w 5")
        result = IOStatResult(self.os, lines)
        return result

    def run_kstat_for_uptime(self):
        lines = self.run_command("kstat -n system_misc -s boot_time -p")
        _, boot_time = lines[0].split()
        uptime_seconds = time.time() - float(boot_time)
        return uptime_seconds

    def run_mpstat(self):
        if self.os == OS.SOLARIS:
            lines = self.run_command(f"mpstat {COMMAND_REPORT_INTERVAL} 2")
        elif self.os == OS.AIX:
            lines = self.run_command(f"mpstat {COMMAND_REPORT_INTERVAL} 1")
        result = MPStatResult(self.os, lines)
        return result

    def run_netstat(self):
        command = f"netstat -in"
        if self.os == OS.FREE_BSD:
            command = f"netstat -in4"
        lines = self.run_command(command)
        interfaces = []
        capture = False
        for line in lines:
            if capture and line.startswith("Name"):
                capture = False
                continue
            if capture:
                try:
                    interfaces.append(Interface.from_line(line))
                except Exception as e:
                    self._log.debug(f"Interface line not processed: {line}, error: {e}")
            if line.startswith("Name") or line.startswith("Iface"):
                capture = True
        return interfaces


    def run_ps_for_top_procs(self) -> List[Process]:
        processes = []
        if self.os == OS.AIX:
            """
            393228      - A     0:00    0   124   124    xx     0     0  0.0  0.0 vmmd
            """
            lines = self.run_command(f"ps avxc | tail -n +2 | sort -rn +2")
            for line in lines:
                try:
                    pid, _, _, _, _, size, rss, _, _, _, cpu_percent, mem_percent, command = line.split()
                    processes.append(Process(int(pid), "", size, rss, cpu_percent, command))
                except Exception as e:
                    self._log.error(f"Error processing process line {line}: {e}")
        elif self.os == OS.HP_UX:
            """
            command         pid    cpu  vsz
            java            21774  2.02 2878264
            """
            lines = self.run_command(f"UNIX95= ps -A -o comm,pid,pcpu,vsz | tail -n +2  | sort -rn +2")
            for line in lines:
                try:
                    command, pid, cpu, vsz = line.split()
                    processes.append(Process(int(pid), "", vsz, vsz, cpu, command))
                except Exception as e:
                    self._log.error(f"Error processing process line {line}: {e}")
        return processes

    def run_ps_for_filtered_procs(self, patterns: dict):
        """
        393228      - A     0:00    0   124   124    xx     0     0  0.0  0.0 vmmd
        """
        result_dict: dict[Process] = {}
        for key in patterns:
            regex = patterns[key]
            filtered_processes = []
            if self.os == OS.HP_UX:
                """
                COMMAND           PID  %CPU     VSZ
                swapper             0  0.00      72
                init                1  0.00    3000
                sh               1220  0.00    5624
                getty           19441  0.00    4196
                evmd             1135  0.00   13420
                """
                command = f"UNIX95= ps -A -o comm,pid,pcpu,vsz | egrep \"{regex}\""
                lines = self.run_command(command)
                for line in lines:
                    try:
                        command, pid, cpu_percent, vsize = line.split()
                        filtered_processes.append(Process(int(pid), "", f"{vsize}K", f"{vsize}K", cpu_percent, command))
                    except Exception as e:
                        self._log.error(f"Error processing process line {line}: {e}")
            elif self.os == OS.FREE_BSD:
                """
                COMMAND           PID  %CPU SSIZ  RSS
                kernel              0   0.0    0 5936
                init                1   0.0  128 1124
                KTLS                2   0.0    0   48
                crypto              3   0.0    0   16
                """
                command = f"ps -Ac -o command,pid,%cpu,ssiz,rss | egrep \"{regex}\""
                lines = self.run_command(command)
                for line in lines:
                    try:
                        command, pid, cpu_percent, size, rss = line.split()
                        filtered_processes.append(Process(int(pid), "", to_bytes(f"{size}K"), rss, cpu_percent, command))
                    except Exception as e:
                        self._log.error(f"Error processing process line {line}: {e}")

            elif self.os == OS.MAC_OS:
                """
                COMMAND            PID  %CPU    RSS
                launchd              1   0.0  12284
                syslogd             72   0.0    720
                UserEventAgent      73   0.0   4244
                """
                command = f"ps -Ac -o command,pid,%cpu,rss | egrep \"{regex}\""
                lines = self.run_command(command)
                for line in lines:
                    try:
                        command, pid, cpu_percent, rss = line.split()
                        filtered_processes.append(Process(int(pid), "", 0, rss, cpu_percent, command))
                    except Exception as e:
                        self._log.error(f"Error processing process line {line}: {e}")

            elif self.os == OS.AIX:
                command = f"ps avxc | grep -e {regex}"
                lines = self.run_command(command)
                for line in lines:
                    try:
                        pid, _, _, _, _, size, rss, _, _, _, cpu_percent, mem_percent, command = line.split()
                        filtered_processes.append(Process(int(pid), "", size, rss, cpu_percent, command))
                    except Exception as e:
                        self._log.error(f"Error processing process line {line}: {e}")

            elif self.os == OS.SOLARIS:
                """
                /usr/lib/ssh/sshd    705     1368 2987  0
                """
                command = f"ps -A -o comm,pid,rss,osz,c | egrep \"{regex}\""
                lines = self.run_command(command)
                for line in lines:
                    try:
                        command, pid, rss, size, cpu_percent= line.split()
                        filtered_processes.append(Process(int(pid), "", size, rss, cpu_percent, command))
                    except Exception as e:
                        self._log.error(f"Error processing process line {line}: {e}")
            result_dict.update({key: filtered_processes})
        return result_dict

    def run_ps_for_uptime(self):
        if self.os == OS.HP_UX:
            time_string = self.run_command(f"UNIX95= LC_ALL=POSIX ps -o etime= -p 1")[0]
        else:
            time_string = self.run_command(f"LC_ALL=POSIX ps -o etime= -p 1")[0]
        """
        2-00:27:25 <-
        [[dd-]hh:]mm:ss
        PID '1' is init i.e. startup time
        """
        if "-" in time_string:
            # 2-00:27:25 (days max)
            match = re.search("(\d+)-(\d+):(\d+):(\d+)", time_string)
            days = int(match.group(1))
            hours = int(match.group(2))
            minutes = int(match.group(3))
            seconds = int(match.group(4))
        elif time_string.count(":") == 2:
            # 00:27:25 (hours max)
            match = re.search("(\d+):(\d+):(\d+)", time_string)
            days = 0
            hours = int(match.group(1))
            minutes = int(match.group(2))
            seconds = int(match.group(3))
        elif time_string.count(":") == 1:
            # 27:25 (minutes max)
            match = re.search("(\d+):(\d+)", time_string)
            days = 0
            hours = 0
            minutes = int(match.group(1))
            seconds = int(match.group(2))

        total_seconds = (days * 86400) + (hours * 3600) + (minutes * 60) + seconds
        return total_seconds

    #AIX
    def run_svmon(self):
        lines = self.run_command(f"svmon -G -O unit=KB")
        result = SvMonResult(self.os, lines)
        return result

    def get_release_info(self):
        if self.os == OS.MAC_OS:
            lines = self.run_command(f"sw_vers")
            for line in lines:
                if line.startswith("ProductName:"):
                    _, product_name = line.split()
                elif line.startswith("ProductVersion:"):
                    _, product_version = line.split()
                elif line.startswith("BuildVersion:"):
                    _, build_version = line.split()
            return f"{product_name} {product_version} ({build_version})"
        else:
            result = EtcReleaseResult(self.run_command(f"cat /etc/*-release"))
            return result.pretty_name

    #AIX
    def get_aix_version(self):
        version = self.run_command("oslevel")[0].strip()
        return version

    #HPUX
    def run_swapinfo_for_memory(self):
        lines = self.run_command("swapinfo -tam")
        result = SwapInfoResult(self.os, lines)
        return result

    #HPUX
    def run_sar_for_disks(self):
        lines = self.run_command(f"sar -dR 5 1")
        disks: List[SarDisk] = []
        for line in lines:
            if "avserv" not in line and len(line.split()) == 9:
                disks.append(SarDisk(self.os, line))
        return disks
        
    #HPUX
    def get_hpux_system_memory(self):
        '''
        ['Memory: 16363 MB (15.98 GB)']
        '''
        lines = self.run_command("/usr/contrib/bin/machinfo -m |grep -i Memory:")
        if 'Memory:' in lines[0]:
            return int(lines[0].split()[1])*1024*1024
        return None
        
    def get_solaris_system_memory(self):
        '''
        Memory size: 16363 MB
        '''
        lines = self.run_command("prtconf | grep Memory")
        if 'Memory size' in lines[0]:
            return int(lines[0].split()[2])*1024*1024
        return None
        
    def get_freebsd_system_memory(self):
        '''
        real memory  = 34359738368 (32768 MB)
        avail memory = 33277898752 (31736 MB)
        '''
        lines = self.run_command("grep -w 'memory' /var/run/dmesg.boot")
        for line in lines:
            if 'real memory' in line:
                return int(line.split()[3])
        return None

    def get_swap_from_swap(self):
        if self.os == OS.SOLARIS:
            line = self.run_command("swap -s")[0]
            return SwapResult(self.os, line)
            
        else:
            self._log.warn(f"Collecting swap metrics from swap command not expected on {self.os.value}")
        
        
# def main():

#     print("Testing VMStat...")
#     remote = RemoteHost(OS('HP-UX'), 'localhost', 'test', 22, 'test')
#     result = remote.run_vmstat()
#     print(str(result))

# if __name__ == "__main__":
#     main()