import time
import logging
import paramiko
from typing import Optional, List


class RemoteClient:
    def __init__(
        self,
        hostname: str,
        port: int,
        username: str,
        password: Optional[str] = None,
        key: Optional[str] = None,
        passphrase: Optional[str] = None,
        log: Optional[logging.Logger] = None
    ):
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password
        self.key = key
        self.passphrase = passphrase
        self.log = log if log is not None else logging.getLogger(__name__)
        self.connected = False

        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        self.client = client

    def __enter__(self) -> "RemoteClient":
        try:
            if self.key is not None:
                self.log.debug("Connecting using key")
                self.client.connect(self.hostname, port=self.port, username=self.username, key_filename=self.key, passphrase=self.passphrase)
            else:
                self.log.debug("Connecting using password")
                self.client.connect(self.hostname, port=self.port, username=self.username, password=self.password, timeout=20)
        except Exception as e:
            self.log.exception(e)
            self.connected = False
        else:
            self.connected = True
        
        return self

    def __exit__(self, e_type, e_value, e_trace) -> bool:
        self.connected = False
        if self.client:
            self.client.close()

        if e_type is not None:
            self.log.exception(e_type, e_value, e_trace)

        return True
    
    def _run_command(self, command: str) -> list:
        self.log.debug(f"Executing command: {command}")
        _, stdout, stderr = self.client.exec_command(command, timeout=30)
        err = stderr.read().decode("utf-8")
        out = stdout.read().decode("utf-8")
        
        exit_status = stdout.channel.recv_exit_status()
        self.log.debug(f"Exit status: {exit_status}")

        stdout_lines = [l.strip() for l in out.split("\n") if l.strip()]
        self.log.debug(f"Lines from stdout: {stdout_lines}")

        stderr_lines = [l.strip() for l in err.split("\n") if l.strip()]
        self.log.debug(f"Lines from stderr: {stderr_lines}")

        return stdout_lines + stderr_lines

    def _run_command_as_user(self, command: str, second_user: str, second_pass: str) -> list:
        self.log.debug(f"Executing command: {command} as user {second_user}")
        
        session = self.client.get_transport().open_session()
        session.set_combine_stderr(True)
        session.get_pty()
        session.exec_command(f'su {second_user} -c "{command}"')
        stdin = session.makefile('wb', -1)
        stdout = session.makefile('rb', -1)
        time.sleep(1) # needed to wait for remote host to be ready for
        stdin.write(second_pass + '\n')
        stdin.flush()
        out = stdout.read().decode("utf-8")
        
        lines = [l.strip() for l in out.split("\n") if l.strip()]
        self.log.debug(f"Lines from stdout: {lines}")

        return lines

    def run_command(
        self,
        command: str,
        metric_delimiter: Optional[str] = None,
        key_value_delimiter: Optional[str] = None,
        second_username: Optional[str] = None,
        second_password: Optional[str] = None
    ) -> List[str]:
        metrics = []
        try:
            if second_username is not None and second_password is not None:
                output = self._run_command_as_user(command, second_username, second_password)
            else:
                output = self._run_command(command)

            if metric_delimiter is not None and key_value_delimiter is not None:
                metric_pairs = []
                if metric_delimiter in ["\n", "\\n"]:
                    metric_pairs.extend(line for line in output if line != "Password:")
                else:
                    metric_pairs.extend(line.split(metric_delimiter) for line in output if line != "Password:")
                metrics.extend(tuple(mp.split(key_value_delimiter)[0:2]) for mp in metric_pairs)
            else:
                metrics.extend(("output", float(line)) for line in output if line != "Password:")
        except Exception as e:
            self.log.exception(e)
        finally:
            return metrics
