import re
import logging
import unicodedata

from generic_linux_cmds_utils import RemoteClient
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import ConfigException
from dynatrace import Dynatrace


log = logging.getLogger(__name__)
METRIC_PREFIX = "com.dynatrace.extension.generic_linux_commands"


class GenericCommandsExtension(RemoteBasePlugin):
    def initialize(self, **kwargs):
        self.dt_client = Dynatrace(self.config.get("api_url"), self.config.get("api_token"), log=log)
        self.executions = 0
        self.failures_detected = 0

    def query(self, **kwargs):
        log.setLevel(self.config.get("log_level"))
        hostname = self.config.get("hostname").strip()
        username = self.config.get("username")
        port = int(self.config.get("port", 22))
        password = self.config.get("password") if self.config.get("password") else None
        second_username = self.config.get("second_username") if self.config.get("second_username") else None
        second_password = self.config.get("second_password") if self.config.get("second_password") else None
        key = self.config.get("ssh_key_file") if self.config.get("ssh_key_file") else None
        passphrase = self.config.get("ssh_key_passphrase") if self.config.get("ssh_key_passphrase") else None
        command = self.config.get("command").strip()
        kv_delimiter = self.config.get("key_value_delimiter") if self.config.get("key_value_delimiter", "") != "" else None
        mp_delimiter = self.config.get("metric_pair_delimiter") if self.config.get("metric_pair_delimiter", "") != "" else None
        frequency = int(self.config.get("frequency")) if self.config.get("frequency") else 15

        if self.executions % frequency == 0:
            raw_metrics, mint_lines = [], []
            with RemoteClient(
                hostname=hostname,
                port=port,
                username=username,
                password=password,
                key=key,
                passphrase=passphrase,
                log=log
            ) as client:
                if not client.connected:
                    log.error("Stopping execution due to SSH connection failure.")
                    raise ConfigException(f"Failed to connect to host {hostname}")
                
                raw_metrics = client.run_command(
                    command=command,
                    metric_delimiter=mp_delimiter,
                    key_value_delimiter=kv_delimiter,
                    second_username=second_username,
                    second_password=second_password
                )
            
            for (mkey, mvalue) in raw_metrics:
                try:
                    mint_lines.append(
                        f'{METRIC_PREFIX}.{slugify(mkey)},hostname="{hostname}",command="{clean_dimension(command)}" {float(mvalue)}'
                    )
                except Exception:
                    continue

            try:
                if mint_lines:
                    log.debug("Sending payload:\n")
                    log.debug("\n".join(mint_lines))
                    self.dt_client.metrics.ingest(mint_lines)
                else:
                    log.info("No metrics to send.")
            except Exception as e:
                log.exception(e)


def slugify(value: str) -> str:
    value = unicodedata.normalize("NFKC", value)
    value = re.sub(r"[:.-/\s]+", "_", value)
    value = re.sub(r"[^\w\s-]", "", value)
    return value.lower()

def clean_dimension(value: str) -> str:
    value = value.replace("\\", "\\\\")
    value = value.replace('"', '\\"')
    if len(value) > 250:
        value = f"{value[:247]}..."
    return value